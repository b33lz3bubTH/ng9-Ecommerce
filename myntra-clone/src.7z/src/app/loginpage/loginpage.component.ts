import {Component, OnInit, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  @ViewChild('f', {static: false}) loginForm: NgForm;
  constructor() { }

  ngOnInit(): void {
  }
  loginSubmit() {
    console.log(this.loginForm.value);
  }
}

import { Component, OnInit } from '@angular/core';
import {OrdersService} from '../sharedServices/orders.service';

@Component({
  selector: 'app-adminpanel',
  templateUrl: './adminpanel.component.html',
  styleUrls: ['./adminpanel.component.css']
})
export class AdminpanelComponent implements OnInit {

  constructor(public ordersServiceObj: OrdersService) { }

  ngOnInit(): void {
  }

}

import {Injectable} from '@angular/core';

@Injectable({providedIn: 'root'})
export class OrdersService {
  public OrderArray = [
    {
      name: 'Demin Jeans',
      price: 2000,
      id: 100,
      processed: true,
      orderedBy: {
        name: 'Sourav',
        email: 'sourab@gmail.com',
        address: 'kolkata - 76',
        phone: '7890128722'
      }
    },
    {
      name: 'Demin Jeans 2',
      price: 2000,
      id: 101,
      processed: true,
      orderedBy: {
        name: 'Sourav',
        email: 'sourab@gmail.com',
        address: 'kolkata - 76',
        phone: '7890128722'
      }
    },
    {
      name: 'Demin Jeans 3',
      price: 2000,
      id: 102,
      processed: true,
      orderedBy: {
        name: 'Suphal',
        email: 'suphal@gmail.com',
        address: 'kolkata - 76',
        phone: '6291048482'
      }
    },
    {
      name: 'Demin Shirt',
      price: 2000,
      id: 200,
      processed: false,
      orderedBy: {
        name: 'Sourav',
        email: 'sourab@gmail.com',
        address: 'kolkata - 76',
        phone: '7890128722'
      }
    },
    {
      name: 'Demin shirt 2',
      price: 2000,
      id: 201,
      processed: false,
      orderedBy: {
        name: 'Sourav',
        email: 'sourab@gmail.com',
        address: 'kolkata - 76',
        phone: '7890128722'
      }
    },
    {
      name: 'Demin shirt 3',
      price: 2000,
      id: 202,
      processed: false,
      orderedBy: {
        name: 'Suphal',
        email: 'suphal@gmail.com',
        address: 'kolkata - 76',
        phone: '6291048482'
      }
    }
  ];
  markProcessed(id) {
    for (const [i, v] of this.OrderArray.entries()) {
      if (v.id === id) {
        v.processed = true;
        return;
      }
    }
  }
  getTotalPendingOrders() {
    let pending = 0;
    for (const [i, v] of this.OrderArray.entries()) {
      if (!v.processed) {
        pending++;
      }
    }
    return pending;
  }
}

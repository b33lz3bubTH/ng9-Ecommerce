export interface AlertBox{
    type: string;
    msg: string;
    validity: boolean;
}
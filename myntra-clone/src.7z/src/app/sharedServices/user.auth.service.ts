import {Injectable} from '@angular/core';

interface UserDetails {
  id: number;
  email: string;
  _token: string;
  _expiry_token_date: Date;
}
@Injectable({providedIn: 'root'})
export class UserAuthService {
  isLogged: boolean;
  isAdmin: boolean;
  userDetail: UserDetails;
  login() {
    // input username
  }
  autoLogin() {
  // from Local storage fetch the user save details
  }
  logOut() {
    // clear local detail storage.
  }
}

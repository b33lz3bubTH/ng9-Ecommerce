import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Product } from '../product/product.model';

@Injectable({providedIn:'root'})
export class ProductsService {
    constructor(private http: HttpClient){}
    getProductForHomePage(){
        return this.http.get<Product[]>('http://localhost/v1/mixprod.php');
    }
    getSearchedProduct(searchedItem){
        return this.http.get<Product[]>('http://localhost/v1/search.php',{
            params: new HttpParams().set('q',searchedItem)
        });
    }
}
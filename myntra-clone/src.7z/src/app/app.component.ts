import { Component, OnInit } from '@angular/core';

import {CartService} from './sharedServices/cart.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [CartService]
})
export class AppComponent implements OnInit {
  constructor(private cartObj: CartService) {
  }
  title = 'myntra-clone';
  ngOnInit() {
    this.cartObj.loadCartFromLocal();
  }
}
